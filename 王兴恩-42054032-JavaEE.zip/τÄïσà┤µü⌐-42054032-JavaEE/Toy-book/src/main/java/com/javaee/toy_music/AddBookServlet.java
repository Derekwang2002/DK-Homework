package com.javaee.toy_music;

import com.javaee.toy_music.Utils.BookUtils;
import com.javaee.toy_music.Utils.CONSTANTS;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@MultipartConfig
@WebServlet(name = "AddBookServlet", value = "/add-book")
public class AddBookServlet extends HttpServlet {


  /**
   * get will redirect to new html
   *
   * @param request
   * @param response
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    HttpSession session = request.getSession();
    String log = (String) session.getAttribute("admin");
    // judge if has login or not
    if (log != null && log.equals("log")) {
      request.getRequestDispatcher("add-book.html").forward(request, response);
    } else {
      response.sendRedirect("admin-login.html");
      return;
    }
  }

  /**
   * post is will real add a book
   *
   * @param request
   * @param response
   * @throws ServletException
   * @throws IOException
   */
  @Override

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    int id = Integer.parseInt(request.getParameter("id"));
    String title = request.getParameter("title").trim();
    String author = request.getParameter("author").trim();
    String description = request.getParameter("description").trim();

    Part part= request.getPart("file");
    String cover="/Users/derekedkwangxingen//Desktop/Cover.png";
    part.write(cover);

    String today = new SimpleDateFormat(CONSTANTS.DATE_FORMAT).format(new Date());
    BookUtils.addBook(id, title, author, cover, description, today);
    System.out.println("add a song");
    // Hint: what if error when adding?
    response.sendRedirect("add-success.html");
    return;
  }
}
